#include "sample.h"

int main() {
  string s1("sample1"), s2("sample2");

  sample_scene(s1);

  other_scene(s2);

  return 0;
}